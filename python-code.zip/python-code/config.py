import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Config:
    # Database Configuration
    MYSQL_HOST = os.getenv("MYSQL_HOST", "localhost")
    MYSQL_USER = os.getenv("MYSQL_USER", "face_user")
    MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "securepassword")
    MYSQL_DB = os.getenv("MYSQL_DB", "face_db")
    
    # File Paths
    UPLOAD_FOLDER = "known_faces"
    ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg"}
    
    # Face Recognition Settings
    MODEL = "hog"  # "cnn" for GPU, "hog" for CPU
    TOLERANCE = 0.55  # Lower = stricter matches
    FRAME_SKIP = 5  # Process every 5th frame for performance
    
    # ESP32 Configuration
    ESP32_IP = os.getenv("ESP32_IP", "192.168.8.100")  # Static IP of ESP32
    ESP32_PORT = int(os.getenv("ESP32_PORT", 80))      # Port ESP32 listens on
    ESP32_ENDPOINT = os.getenv("ESP32_ENDPOINT", "/door")  # ESP32 endpoint for door control
    
    # Security Settings
    SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-change-in-production")
    JWT_EXPIRATION_HOURS = int(os.getenv("JWT_EXPIRATION_HOURS", 1))
    
    # Application Settings
    DEBUG = os.getenv("DEBUG", "False").lower() == 'true'
    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", 5000))
    
    # SSL Settings
    SSL_CERT_PATH = os.getenv("SSL_CERT_PATH", "cert.pem")
    SSL_KEY_PATH = os.getenv("SSL_KEY_PATH", "key.pem")
    
    # Request Timeout Settings (in seconds)
    ESP32_TIMEOUT = int(os.getenv("ESP32_TIMEOUT", 3))
    DATABASE_TIMEOUT = int(os.getenv("DATABASE_TIMEOUT", 10))
    
    # Logging Settings
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE = os.getenv("LOG_FILE", "app.log")
    
    # Image Processing Settings
    MAX_IMAGE_SIZE = int(os.getenv("MAX_IMAGE_SIZE", 10))  # Maximum image size in MB
    IMAGE_QUALITY = int(os.getenv("IMAGE_QUALITY", 85))  # JPEG quality (1-100)
    
    # Access Control Settings
    MAX_LOGIN_ATTEMPTS = int(os.getenv("MAX_LOGIN_ATTEMPTS", 3))
    ACCOUNT_LOCKOUT_MINUTES = int(os.getenv("ACCOUNT_LOCKOUT_MINUTES", 5))
    
    # SMS Settings (for Arduino Mega)
    ADMIN_PHONE_NUMBER = os.getenv("ADMIN_PHONE_NUMBER", "+1234567890")
    SYSTEM_PHONE_NUMBER = os.getenv("SYSTEM_PHONE_NUMBER", "+0987654321")
    
    # Door Control Settings
    DOOR_OPEN_DURATION = int(os.getenv("DOOR_OPEN_DURATION", 5))  # seconds
    SERVO_OPEN_ANGLE = int(os.getenv("SERVO_OPEN_ANGLE", 90))
    SERVO_CLOSED_ANGLE = int(os.getenv("SERVO_CLOSED_ANGLE", 0))
    
    @classmethod
    def init_app(cls):
        """Initialize application configuration"""
        # Create necessary directories
        os.makedirs(cls.UPLOAD_FOLDER, exist_ok=True)
        os.makedirs("static", exist_ok=True)
        os.makedirs("templates", exist_ok=True)
        os.makedirs("logs", exist_ok=True)
        
        # Validate critical settings
        cls._validate_settings()
    
    @classmethod
    def _validate_settings(cls):
        """Validate critical configuration settings"""
        # Check if SSL certificates exist
        if not (os.path.exists(cls.SSL_CERT_PATH) and os.path.exists(cls.SSL_KEY_PATH)):
            print(f"Warning: SSL certificates not found at {cls.SSL_CERT_PATH} and {cls.SSL_KEY_PATH}")
            print("The application will generate self-signed certificates on first run.")
        
        # Validate ESP32 IP format
        if not cls._is_valid_ip(cls.ESP32_IP):
            print(f"Warning: ESP32_IP '{cls.ESP32_IP}' doesn't appear to be a valid IP address")
        
        # Validate port numbers
        if not (1 <= cls.ESP32_PORT <= 65535):
            print(f"Warning: ESP32_PORT {cls.ESP32_PORT} is not a valid port number")
        
        if not (1 <= cls.PORT <= 65535):
            print(f"Warning: PORT {cls.PORT} is not a valid port number")
        
        # Validate timeouts
        if cls.ESP32_TIMEOUT <= 0:
            print("Warning: ESP32_TIMEOUT should be a positive number")
        
        if cls.DATABASE_TIMEOUT <= 0:
            print("Warning: DATABASE_TIMEOUT should be a positive number")
    
    @staticmethod
    def _is_valid_ip(ip):
        """Check if the given string is a valid IP address"""
        parts = ip.split('.')
        if len(parts) != 4:
            return False
        try:
            return all(0 <= int(part) <= 255 for part in parts)
        except ValueError:
            return False
    
    @classmethod
    def get_database_url(cls):
        """Get database connection URL"""
        return f"mysql://{cls.MYSQL_USER}:{cls.MYSQL_PASSWORD}@{cls.MYSQL_HOST}/{cls.MYSQL_DB}"
    
    @classmethod
    def get_esp32_url(cls):
        """Get ESP32 base URL"""
        return f"http://{cls.ESP32_IP}:{cls.ESP32_PORT}"
    
    @classmethod
    def get_esp32_door_url(cls):
        """Get ESP32 door control URL"""
        return f"{cls.get_esp32_url()}{cls.ESP32_ENDPOINT}"