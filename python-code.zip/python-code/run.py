import os
import sys
import subprocess
import time
import signal
import threading
import logging

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def check_dependencies():
    """Check if all required dependencies are installed"""
    required_packages = [
        'flask', 'mysql-connector-python', 'PyJWT', 'requests', 
        'face-recognition', 'opencv-python', 'numpy', 'dlib'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        logger.error(f"Missing packages: {', '.join(missing_packages)}")
        logger.info("Installing missing packages...")
        
        for package in missing_packages:
            logger.info(f"Installing {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        
        logger.info("All packages installed successfully")
    else:
        logger.info("All dependencies are satisfied")

def generate_certificate():
    """Generate SSL certificate if it doesn't exist"""
    if not (os.path.exists('cert.pem') and os.path.exists('key.pem')):
        logger.info("Generating SSL certificate...")
        try:
            from OpenSSL import crypto, SSL
            
            # Create a key pair
            k = crypto.PKey()
            k.generate_key(crypto.TYPE_RSA, 4096)
            
            # Create a self-signed cert
            cert = crypto.X509()
            cert.get_subject().C = "US"
            cert.get_subject().ST = "California"
            cert.get_subject().L = "San Francisco"
            cert.get_subject().O = "My Company"
            cert.get_subject().OU = "My Department"
            cert.get_subject().CN = "localhost"
            cert.set_serial_number(1000)
            cert.gmtime_adj_notBefore(0)
            cert.gmtime_adj_notAfter(365 * 24 * 60 * 60)
            cert.set_issuer(cert.get_subject())
            cert.set_pubkey(k)
            cert.sign(k, 'sha256')
            
            # Write cert and key to files
            with open("cert.pem", "wt") as f:
                f.write(crypto.dump_certificate(crypto.FILETYPE_PEM, cert).decode())
            with open("key.pem", "wt") as f:
                f.write(crypto.dump_privatekey(crypto.FILETYPE_PEM, k).decode())
            
            logger.info("SSL certificate generated successfully")
        except Exception as e:
            logger.error(f"Failed to generate SSL certificate: {e}")
            logger.info("Please generate certificate manually")
            sys.exit(1)
    else:
        logger.info("SSL certificate already exists")

def start_app():
    """Start the Flask application"""
    try:
        # Import app here to avoid issues if dependencies were just installed
        from app import app, logger
        
        # SSL context with modern TLS
        try:
            # Try to use the most secure TLS version available
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.load_cert_chain('cert.pem', 'key.pem')
            logger.info("Using modern TLS context")
        except Exception as e:
            logger.warning(f"Failed to create modern TLS context: {e}")
            # Fall back to a compatible version
            context = ssl.SSLContext(ssl.PROTOCOL_TLS)
            context.load_cert_chain('cert.pem', 'key.pem')
            logger.info("Using fallback TLS context")
        
        logger.info("Starting Flask application...")
        logger.info("Server will run on https://0.0.0.0:5000")
        
        # Run the app
        app.run(host="0.0.0.0", port=5000, ssl_context=context, debug=False, threaded=True)
    except Exception as e:
        logger.error(f"Failed to start application: {e}")
        import traceback
        logger.error(traceback.format_exc())
        sys.exit(1)

def main():
    """Main function"""
    logger.info("Starting Face Recognition System...")
    
    # Check dependencies
    check_dependencies()
    
    # Generate SSL certificate
    generate_certificate()
    
    # Start the application
    start_app()

if __name__ == "__main__":
    main()