// DOM Elements
const loginSection = document.getElementById('loginSection');
const mainApp = document.getElementById('mainApp');
const loginForm = document.getElementById('loginForm');
const loginResult = document.getElementById('loginResult');

// Tab elements
const recognitionTab = document.getElementById('recognitionTab');
const registrationTab = document.getElementById('registrationTab');
const recognitionContent = document.getElementById('recognitionContent');
const registrationContent = document.getElementById('registrationContent');

// Recognition elements
const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const captureBtn = document.getElementById('captureBtn');
const verifyBtn = document.getElementById('verifyBtn');
const verifyResult = document.getElementById('verifyResult');
const doorStatus = document.getElementById('doorStatus');
const doorText = document.getElementById('doorText');
const doorIcon = document.getElementById('doorIcon');
const verifyCameraSection = document.getElementById('verifyCameraSection');
const verifyPreviewSection = document.getElementById('verifyPreviewSection');
const verifyPreview = document.getElementById('verifyPreview');
const retakeVerifyBtn = document.getElementById('retakeVerifyBtn');
const confirmVerifyBtn = document.getElementById('confirmVerifyBtn');
const verifySection = document.getElementById('verifySection');

// Registration elements
const registerVideo = document.getElementById('registerVideo');
const registerCanvas = document.getElementById('registerCanvas');
const registerCtx = registerCanvas.getContext('2d');
const registerCaptureBtn = document.getElementById('registerCaptureBtn');
const registerImageData = document.getElementById('registerImageData');
const registerForm = document.getElementById('registerForm');
const registerResult = document.getElementById('registerResult');
const registerCameraSection = document.getElementById('registerCameraSection');
const registerPreviewSection = document.getElementById('registerPreviewSection');
const registerPreview = document.getElementById('registerPreview');
const retakeRegisterBtn = document.getElementById('retakeRegisterBtn');
const confirmRegisterBtn = document.getElementById('confirmRegisterBtn');
const registerSection = document.getElementById('registerSection');
const submitRegisterBtn = document.getElementById('submitRegisterBtn');

// User Management elements
const refreshUsersBtn = document.getElementById('refreshUsersBtn');
const usersList = document.getElementById('usersList');

// Add this helper function at the top
function handleApiError(response, errorElement) {
    if (!response.ok) {
        response.json().then(data => {
            const errorMsg = data.error || data.message || 'Unknown error';
            showToast(errorMsg, 'error');
            if (errorElement) {
                errorElement.textContent = errorMsg;
                errorElement.className = "text-red-600";
            }
        }).catch(() => {
            showToast('Network error', 'error');
            if (errorElement) {
                errorElement.textContent = 'Network error';
                errorElement.className = "text-red-600";
            }
        });
        return true;
    }
    return false;
}

// Update the verifyBtn event listener
verifyBtn.addEventListener('click', async () => {
    if (!capturedImage) return;
    
    verifyBtn.disabled = true;
    verifyResult.classList.remove('hidden');
    verifyResult.textContent = "Processing...";
    verifyResult.className = "text-blue-600";
    
    try {
        const blob = await fetch(capturedImage).then(res => res.blob());
        const formData = new FormData();
        formData.append('image', blob, 'verify.jpg');
        
        const response = await fetch('/api/recognize', {
            method: 'POST',
            body: formData
        });
        
        if (handleApiError(response, verifyResult)) {
            verifyBtn.disabled = false;
            return;
        }
        
        const result = await response.json();
        
        if (result.match) {
            verifyResult.textContent = `Access Granted! Welcome, ${result.name}`;
            verifyResult.className = "text-green-600 font-bold";
            
            // Show door command status
            if (result.door_command_sent) {
                showToast('Door command sent successfully', 'success');
            } else {
                showToast('Warning: Failed to send door command', 'error');
            }
            
            // Simulate door unlock
            doorStatus.classList.remove('hidden');
            doorText.textContent = "Door Unlocked";
            doorIcon.textContent = "🚪✨";
            
            setTimeout(() => {
                doorText.textContent = "Door Locked";
                doorIcon.textContent = "🚪";
            }, 3000);
        } else {
            verifyResult.textContent = result.message || "Access Denied!";
            verifyResult.className = "text-red-600 font-bold";
        }
    } catch (error) {
        console.error("Verification error:", error);
        showToast('Verification failed', 'error');
        verifyResult.textContent = "Verification error";
        verifyResult.className = "text-red-600";
    } finally {
        verifyBtn.disabled = false;
    }
});

// Update the registerForm event listener
registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = document.querySelector('input[name="name"]').value.trim();
    
    if (!name || !registerCapturedImage) {
        showToast('Please fill all fields and capture a face', 'error');
        return;
    }
    
    registerResult.classList.remove('hidden');
    registerResult.textContent = "Registering...";
    registerResult.className = "text-blue-600";
    
    try {
        const blob = await fetch(registerCapturedImage).then(res => res.blob());
        const formData = new FormData();
        formData.append('name', name);
        formData.append('image', blob, 'register.jpg');
        
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`
            },
            body: formData
        });
        
        if (handleApiError(response, registerResult)) {
            return;
        }
        
        const result = await response.json();
        
        if (result.success) {
            registerResult.textContent = "Registration successful!";
            registerResult.className = "text-green-600";
            registerForm.reset();
            registerCapturedImage = null;
            showSection(registerCameraSection, [registerSection, registerPreviewSection]);
            initCameras(); // Restart camera for next registration
            loadUsers(); // Refresh user list
            showToast('Registration successful!', 'success');
        } else {
            registerResult.textContent = result.error || "Registration failed";
            registerResult.className = "text-red-600";
        }
    } catch (error) {
        console.error("Registration error:", error);
        showToast('Registration failed', 'error');
        registerResult.textContent = "Registration error";
        registerResult.className = "text-red-600";
    }
});
// State
let capturedImage = null;
let registerCapturedImage = null;
let authToken = null;
let verifyStream = null;
let registerStream = null;

// Initialize Cameras
async function initCameras() {
    try {
        // Recognition camera
        verifyStream = await navigator.mediaDevices.getUserMedia({ 
            video: { 
                facingMode: 'user', // Front camera
                width: { ideal: 1280 }, 
                height: { ideal: 720 } 
            } 
        });
        video.srcObject = verifyStream;

        // Registration camera
        registerStream = await navigator.mediaDevices.getUserMedia({ 
            video: { 
                facingMode: 'user', // Front camera
                width: { ideal: 1280 }, 
                height: { ideal: 720 } 
            } 
        });
        registerVideo.srcObject = registerStream;
    } catch (err) {
        console.error("Camera error:", err);
        showToast('Camera access is required for this application', 'error');
    }
}

// Stop camera stream
function stopCameraStream(stream) {
    if (stream) {
        stream.getTracks().forEach(track => track.stop());
    }
}

// Show section helper
function showSection(sectionToShow, sectionsToHide) {
    sectionsToHide.forEach(section => {
        if (section) section.classList.remove('active');
    });
    if (sectionToShow) sectionToShow.classList.add('active');
}

// Tab switching
recognitionTab.addEventListener('click', () => {
    recognitionTab.classList.add('border-blue-500', 'text-blue-600');
    recognitionTab.classList.remove('border-transparent', 'text-gray-500');
    registrationTab.classList.add('border-transparent', 'text-gray-500');
    registrationTab.classList.remove('border-blue-500', 'text-blue-600');
    
    recognitionContent.classList.add('active');
    registrationContent.classList.remove('active');
});

registrationTab.addEventListener('click', () => {
    registrationTab.classList.add('border-blue-500', 'text-blue-600');
    registrationTab.classList.remove('border-transparent', 'text-gray-500');
    recognitionTab.classList.add('border-transparent', 'text-gray-500');
    recognitionTab.classList.remove('border-blue-500', 'text-blue-600');
    
    registrationContent.classList.add('active');
    recognitionContent.classList.remove('active');
});

// Login
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    loginResult.classList.remove('hidden');
    loginResult.textContent = "Logging in...";
    loginResult.className = "text-blue-600";
    
    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
        
        const result = await response.json();
        
        if (result.token) {
            authToken = result.token;
            loginSection.classList.add('hidden');
            mainApp.classList.remove('hidden');
            initCameras();
            loadUsers();
        } else {
            loginResult.textContent = result.message || 'Login failed';
            loginResult.className = "text-red-600";
        }
    } catch (error) {
        console.error("Login error:", error);
        loginResult.textContent = "Login failed";
        loginResult.className = "text-red-600";
    }
});

// Capture Face for Recognition
captureBtn.addEventListener('click', () => {
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    capturedImage = canvas.toDataURL('image/jpeg');
    verifyPreview.src = capturedImage;
    
    // Stop camera and show preview
    stopCameraStream(verifyStream);
    showSection(verifyPreviewSection, [verifyCameraSection, verifySection]);
    
    showToast('Face captured successfully', 'success');
});

// Retake Recognition Photo
retakeVerifyBtn.addEventListener('click', () => {
    // Restart camera and show camera section
    initCameras();
    showSection(verifyCameraSection, [verifyPreviewSection, verifySection]);
    
    capturedImage = null;
});

// Confirm Recognition Photo
confirmVerifyBtn.addEventListener('click', () => {
    showSection(verifySection, [verifyPreviewSection, verifyCameraSection]);
    showToast('Photo confirmed, ready to verify', 'success');
});

// Verify Face
verifyBtn.addEventListener('click', async () => {
    if (!capturedImage) return;
    
    verifyBtn.disabled = true;
    verifyResult.classList.remove('hidden');
    verifyResult.textContent = "Processing...";
    verifyResult.className = "text-blue-600";
    
    try {
        const blob = await fetch(capturedImage).then(res => res.blob());
        const formData = new FormData();
        formData.append('image', blob, 'verify.jpg');
        
        const response = await fetch('/api/recognize', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.match) {
            verifyResult.textContent = `Access Granted! Welcome, ${result.name}`;
            verifyResult.className = "text-green-600 font-bold";
            
            // Simulate door unlock
            doorStatus.classList.remove('hidden');
            doorText.textContent = "Door Unlocked";
            doorIcon.textContent = "🚪✨";
            
            setTimeout(() => {
                doorText.textContent = "Door Locked";
                doorIcon.textContent = "🚪";
            }, 3000);
        } else {
            verifyResult.textContent = "Access Denied!";
            verifyResult.className = "text-red-600 font-bold";
        }
    } catch (error) {
        console.error("Verification error:", error);
        showToast('Verification failed', 'error');
    } finally {
        verifyBtn.disabled = false;
    }
});

// Capture Face for Registration
registerCaptureBtn.addEventListener('click', () => {
    registerCanvas.width = registerVideo.videoWidth;
    registerCanvas.height = registerVideo.videoHeight;
    registerCtx.drawImage(registerVideo, 0, 0, registerCanvas.width, registerCanvas.height);
    
    registerCapturedImage = registerCanvas.toDataURL('image/jpeg');
    registerPreview.src = registerCapturedImage;
    
    // Stop camera and show preview
    stopCameraStream(registerStream);
    showSection(registerPreviewSection, [registerCameraSection, registerSection]);
    
    showToast('Face captured for registration', 'success');
});

// Retake Registration Photo
retakeRegisterBtn.addEventListener('click', () => {
    // Restart camera and show camera section
    initCameras();
    showSection(registerCameraSection, [registerPreviewSection, registerSection]);
    
    registerCapturedImage = null;
});

// Confirm Registration Photo
confirmRegisterBtn.addEventListener('click', () => {
    registerImageData.value = registerCapturedImage;
    showSection(registerSection, [registerPreviewSection, registerCameraSection]);
    showToast('Photo confirmed, ready to register', 'success');
});

// Register Face
registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = document.querySelector('input[name="name"]').value.trim();
    
    if (!name || !registerCapturedImage) {
        showToast('Please fill all fields and capture a face', 'error');
        return;
    }
    
    registerResult.classList.remove('hidden');
    registerResult.textContent = "Registering...";
    registerResult.className = "text-blue-600";
    
    try {
        const blob = await fetch(registerCapturedImage).then(res => res.blob());
        const formData = new FormData();
        formData.append('name', name);
        formData.append('image', blob, 'register.jpg');
        
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`
            },
            body: formData
        });
        
        const result = await response.json();
        
        if (result.error) {
            registerResult.textContent = result.error;
            registerResult.className = "text-red-600";
        } else {
            registerResult.textContent = "Registration successful!";
            registerResult.className = "text-green-600";
            registerForm.reset();
            registerCapturedImage = null;
            showSection(registerCameraSection, [registerSection, registerPreviewSection]);
            initCameras(); // Restart camera for next registration
            loadUsers(); // Refresh user list
        }
    } catch (error) {
        console.error("Registration error:", error);
        registerResult.textContent = "Registration failed";
        registerResult.className = "text-red-600";
    }
});

// Load Users
async function loadUsers() {
    try {
        const response = await fetch('/api/users', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        const result = await response.json();
        
        if (result.users) {
            usersList.innerHTML = '';
            result.users.forEach(user => {
                const userDiv = document.createElement('div');
                userDiv.className = 'flex justify-between items-center p-3 bg-gray-50 rounded-lg';
                userDiv.innerHTML = `
                    <div>
                        <span class="font-medium">${user.name}</span>
                        <span class="text-sm text-gray-500 ml-2">(ID: ${user.id})</span>
                    </div>
                    <button onclick="deleteUser(${user.id})" class="bg-red-500 hover:bg-red-600 text-white py-1 px-3 rounded text-sm">
                        Delete
                    </button>
                `;
                usersList.appendChild(userDiv);
            });
        }
    } catch (error) {
        console.error("Error loading users:", error);
        showToast('Failed to load users', 'error');
    }
}

// Delete User
async function deleteUser(userId) {
    if (!confirm('Are you sure you want to delete this user?')) return;
    
    try {
        const response = await fetch(`/api/users/${userId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        const result = await response.json();
        
        if (result.success) {
            showToast('User deleted successfully', 'success');
            loadUsers(); // Refresh the list
        } else {
            showToast(result.error || 'Failed to delete user', 'error');
        }
    } catch (error) {
        console.error("Error deleting user:", error);
        showToast('Failed to delete user', 'error');
    }
}

// Refresh Users
refreshUsersBtn.addEventListener('click', loadUsers);

// Helper Functions
function showToast(message, type) {
    const toast = document.createElement('div');
    toast.className = `fixed top-4 right-4 px-6 py-3 rounded-lg shadow-lg text-white ${
        type === 'success' ? 'bg-green-500' : 'bg-red-500'
    }`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// Initialize App
// We don't initialize cameras until after login