from flask import Flask, request, jsonify, render_template
import mysql.connector
import pickle
import os
from datetime import datetime, timedelta
from config import Config
from face_engine import FaceEngine
import logging
from functools import wraps
import jwt
from werkzeug.security import generate_password_hash, check_password_hash
import ssl
import requests
import traceback
import threading
import signal
import sys
from flask_cors import CORS  # Add this import

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

Config.init_app()
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'your-secret-key-here')

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('app.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Global flag for graceful shutdown
shutdown_flag = False

# Graceful shutdown handler
def signal_handler(sig, frame):
    global shutdown_flag
    logger.info("Shutting down gracefully...")
    shutdown_flag = True
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

# Database Connection
def get_db():
    try:
        conn = mysql.connector.connect(
            host=Config.MYSQL_HOST,
            user=Config.MYSQL_USER,
            password=Config.MYSQL_PASSWORD,
            database=Config.MYSQL_DB,
            pool_name="mypool",
            pool_size=5
        )
        return conn
    except mysql.connector.Error as err:
        logger.error(f"Database connection error: {err}")
        raise

# Initialize Database
def init_db():
    try:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                image_path VARCHAR(255) NOT NULL,
                encoding BLOB NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS access_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NULL,
                access_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                access_granted BOOLEAN,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
            """)
            # Create admin user table for authentication
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS admins (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL
            )
            """)
            conn.commit()
            # Check if admin exists, if not create one
            cursor.execute("SELECT * FROM admins WHERE username = 'admin'")
            if not cursor.fetchone():
                hashed_password = generate_password_hash('admin123')
                cursor.execute("INSERT INTO admins (username, password_hash) VALUES (%s, %s)",
                               ('admin', hashed_password))
                conn.commit()
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Database initialization error: {e}")
        raise

# Function to send door command to ESP32
def send_door_command_to_esp32(user_name):
    try:
        esp32_url = f"http://{Config.ESP32_IP}:{Config.ESP32_PORT}/door"
        payload = {
            "type": "face",
            "status": "granted",
            "user": user_name
        }
        headers = {'Content-Type': 'application/json'}
        
        # Log the attempt
        logger.info(f"Sending door command to ESP32 at {esp32_url}")
        logger.info(f"Payload: {payload}")
        
        # Send the request with a timeout
        response = requests.post(esp32_url, json=payload, headers=headers, timeout=3)
        
        if response.status_code == 200:
            logger.info(f"Door command sent successfully to ESP32 for user: {user_name}")
            return True
        else:
            logger.error(f"Failed to send door command. ESP32 responded with: {response.status_code}")
            return False
    except requests.exceptions.Timeout:
        logger.error("Timeout while sending door command to ESP32")
        return False
    except requests.exceptions.ConnectionError:
        logger.error("Connection error while sending door command to ESP32")
        return False
    except Exception as e:
        logger.error(f"Error sending door command to ESP32: {e}")
        return False

# Function to send door command asynchronously
def send_door_command_async(user_name):
    thread = threading.Thread(target=send_door_command_to_esp32, args=(user_name,))
    thread.daemon = True
    thread.start()

# Authentication decorator
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'message': 'Token is missing'}), 401
        try:
            token = token.split(' ')[1]  # Remove 'Bearer ' prefix
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
            # You can add more checks here if needed
        except jwt.ExpiredSignatureError:
            return jsonify({'message': 'Token has expired'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'message': 'Token is invalid'}), 401
        except Exception as e:
            logger.error(f"Token validation error: {e}")
            return jsonify({'message': 'Token validation failed'}), 401
        return f(*args, **kwargs)
    return decorated

# API Endpoints
@app.route("/")
def home():
    try:
        return render_template("index.html")
    except Exception as e:
        logger.error(f"Error rendering home page: {e}")
        return jsonify({"error": "Internal server error"}), 500

@app.route("/api/login", methods=['POST'])
def login():
    try:
        auth = request.json
        if not auth or not auth.get('username') or not auth.get('password'):
            return jsonify({'message': 'Could not verify'}), 400
        
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT password_hash FROM admins WHERE username = %s", (auth['username'],))
            user = cursor.fetchone()
        
        if not user:
            return jsonify({'message': 'Invalid credentials'}), 401
        
        if check_password_hash(user[0], auth['password']):
            token = jwt.encode({
                'username': auth['username'],
                'exp': datetime.utcnow() + timedelta(hours=1)
            }, app.config['SECRET_KEY'])
            return jsonify({'token': token})
        
        return jsonify({'message': 'Invalid credentials'}), 401
    except Exception as e:
        logger.error(f"Login error: {e}")
        return jsonify({'message': 'Login failed'}), 500

@app.route("/api/register", methods=["POST"])
@token_required
def register():
    try:
        if "image" not in request.files or "name" not in request.form:
            return jsonify({"error": "Missing data"}), 400
        
        file = request.files["image"]
        name = request.form["name"].strip()
        
        # Validate name
        if not name or len(name) > 100:
            return jsonify({"error": "Invalid name"}), 400
        
        if not FaceEngine.validate_image(file):
            return jsonify({"error": "Invalid image format"}), 400
        
        # Create a safe filename
        safe_name = "".join(c for c in name if c.isalnum() or c in (' ', '-', '_')).rstrip()
        filename = f"{safe_name}_{datetime.now().strftime('%Y%m%d%H%M%S')}.jpg"
        save_path = os.path.join(Config.UPLOAD_FOLDER, filename)
        
        try:
            file.save(save_path)
        except Exception as e:
            logger.error(f"Error saving image: {e}")
            return jsonify({"error": "Failed to save image"}), 500
        
        try:
            if not FaceEngine.is_valid_registration(save_path):
                os.remove(save_path)
                return jsonify({"error": "Invalid face detected"}), 400
            
            encoding = FaceEngine.get_encodings(save_path)[0]
        except Exception as e:
            logger.error(f"Error processing face: {e}")
            if os.path.exists(save_path):
                os.remove(save_path)
            return jsonify({"error": "Failed to process face"}), 500
        
        try:
            with get_db() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "INSERT INTO users (name, image_path, encoding) VALUES (%s, %s, %s)",
                    (name, save_path, pickle.dumps(encoding))
                )
                conn.commit()
        except mysql.connector.Error as err:
            logger.error(f"Database error: {err}")
            if os.path.exists(save_path):
                os.remove(save_path)
            return jsonify({"error": "Failed to register user"}), 500
        
        logger.info(f"User registered successfully: {name}")
        return jsonify({"success": True, "message": "Registration successful"})
    except Exception as e:
        logger.error(f"Registration error: {e}\n{traceback.format_exc()}")
        return jsonify({"error": "Registration failed"}), 500

@app.route("/api/recognize", methods=["POST"])
def recognize():
    temp_path = None
    try:
        if "image" not in request.files:
            return jsonify({"error": "No image provided"}), 400
        
        temp_path = "static/temp_verify.jpg"
        try:
            request.files["image"].save(temp_path)
        except Exception as e:
            logger.error(f"Error saving temp image: {e}")
            return jsonify({"error": "Failed to process image"}), 500
        
        try:
            with get_db() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT id, encoding FROM users")
                users = cursor.fetchall()
                known_encodings = [pickle.loads(row[1]) for row in users]
                user_ids = [row[0] for row in users]
            
            if not known_encodings:
                logger.warning("No registered users found")
                return jsonify({"match": False, "message": "No registered users"})
            
            match_index = FaceEngine.recognize(temp_path, known_encodings)
        except Exception as e:
            logger.error(f"Recognition error: {e}")
            return jsonify({"error": "Recognition failed"}), 500
        
        user_id = None
        access_granted = False
        user_name = None
        if match_index is not None:
            user_id = user_ids[match_index]
            access_granted = True
            # Get user name for response
            try:
                with get_db() as conn:
                    cursor = conn.cursor()
                    cursor.execute("SELECT name FROM users WHERE id = %s", (user_id,))
                    user_name = cursor.fetchone()[0]
            except Exception as e:
                logger.error(f"Error fetching user name: {e}")
        
        # Log access attempt
        try:
            with get_db() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "INSERT INTO access_logs (user_id, access_granted) VALUES (%s, %s)",
                    (user_id, access_granted)
                )
                conn.commit()
        except mysql.connector.Error as err:
            logger.error(f"Error logging access: {err}")
        
        if access_granted and user_name:
            # Immediately send door command to ESP32 (asynchronously to not block response)
            send_door_command_async(user_name)
            
            logger.info(f"Access granted to user: {user_name}")
            return jsonify({
                "match": True, 
                "user_id": user_id, 
                "name": user_name,
                "door_command_sent": True  # We assume it was sent since we're doing it async
            })
        else:
            logger.warning("Access denied")
            return jsonify({"match": False})
    except Exception as e:
        logger.error(f"Recognition error: {e}\n{traceback.format_exc()}")
        return jsonify({"error": "Recognition failed"}), 500
    finally:
        if temp_path and os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except Exception as e:
                logger.error(f"Error removing temp file: {e}")

# Add this new endpoint to match what the frontend expects
@app.route("/api/face-recognition", methods=["POST"])
def face_recognition():
    # This is just an alias for the recognize endpoint
    return recognize()

@app.route("/api/capture", methods=["POST"])
@token_required
def capture():
    try:
        image_path = FaceEngine.capture_face()
        if image_path:
            return jsonify({"success": True, "image_path": image_path})
        return jsonify({"error": "Face capture failed"}), 500
    except Exception as e:
        logger.error(f"Capture error: {e}")
        return jsonify({"error": "Capture failed"}), 500

@app.route("/api/users", methods=["GET"])
@token_required
def list_users():
    try:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, name, image_path, created_at FROM users")
            users = cursor.fetchall()
        user_list = []
        for user in users:
            user_list.append({
                "id": user[0],
                "name": user[1],
                "image_path": user[2],
                "created_at": user[3].isoformat() if user[3] else None
            })
        return jsonify({"users": user_list})
    except Exception as e:
        logger.error(f"Error listing users: {e}")
        return jsonify({"error": "Failed to list users"}), 500

@app.route("/api/users/<int:user_id>", methods=["DELETE"])
@token_required
def delete_user(user_id):
    try:
        with get_db() as conn:
            cursor = conn.cursor()
            # Get image path to delete file
            cursor.execute("SELECT image_path FROM users WHERE id = %s", (user_id,))
            user = cursor.fetchone()
            if not user:
                return jsonify({"error": "User not found"}), 404
            
            image_path = user[0]
            cursor.execute("DELETE FROM users WHERE id = %s", (user_id,))
            conn.commit()
            
            # Delete image file
            if os.path.exists(image_path):
                os.remove(image_path)
                
        logger.info(f"User deleted: {user_id}")
        return jsonify({"success": True, "message": "User deleted"})
    except Exception as e:
        logger.error(f"Error deleting user: {e}")
        return jsonify({"error": "Failed to delete user"}), 500

# Add a health check endpoint
@app.route("/api/health", methods=["GET"])
def health_check():
    try:
        # Check database connection
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            cursor.fetchone()
        
        return jsonify({
            "status": "running",
            "message": "Server is healthy",
            "timestamp": datetime.now().isoformat(),
            "database": "connected"
        })
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return jsonify({
            "status": "error",
            "message": "Server is unhealthy",
            "timestamp": datetime.now().isoformat(),
            "database": "disconnected"
        }), 500

@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Not found"}), 404

@app.errorhandler(500)
def internal_error(error):
    logger.error(f"Internal server error: {error}")
    return jsonify({"error": "Internal server error"}), 500

if __name__ == "__main__":
    try:
        init_db()
        
        # Create required directories
        os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
        os.makedirs("static", exist_ok=True)
        os.makedirs("templates", exist_ok=True)
        
        # For development, run without SSL to match frontend expectations
        if os.environ.get('FLASK_ENV') == 'development':
            logger.info("Starting Flask application in development mode...")
            logger.info("Server will run on http://0.0.0.0:5000")
            app.run(host="0.0.0.0", port=5000, debug=True, threaded=True)
        else:
            # SSL context with modern TLS for production
            try:
                # Try to use the most secure TLS version available
                context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
                context.load_cert_chain('cert.pem', 'key.pem')
                logger.info("Using modern TLS context")
            except Exception as e:
                logger.warning(f"Failed to create modern TLS context: {e}")
                # Fall back to a compatible version
                context = ssl.SSLContext(ssl.PROTOCOL_TLS)
                context.load_cert_chain('cert.pem', 'key.pem')
                logger.info("Using fallback TLS context")
            
            logger.info("Starting Flask application...")
            logger.info("Server will run on https://0.0.0.0:5000")
            
            # Run the app
            app.run(host="0.0.0.0", port=5000, ssl_context=context, debug=False, threaded=True)
    except Exception as e:
        logger.error(f"Failed to start application: {e}\n{traceback.format_exc()}")