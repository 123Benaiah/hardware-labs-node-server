import cv2
import face_recognition
import numpy as np
import os
from config import Config
import logging

logger = logging.getLogger(__name__)

class FaceEngine:
    @staticmethod
    def validate_image(file):
        try:
            filename = file.filename
            return "." in filename and \
                   filename.rsplit(".", 1)[1].lower() in Config.ALLOWED_EXTENSIONS
        except Exception as e:
            logger.error(f"Error validating image: {e}")
            return False

    @staticmethod
    def get_encodings(image_path):
        try:
            if not os.path.exists(image_path):
                logger.error(f"Image file not found: {image_path}")
                return []
            
            image = face_recognition.load_image_file(image_path)
            encodings = face_recognition.face_encodings(image)
            
            if not encodings:
                logger.warning(f"No face found in image: {image_path}")
            
            return encodings
        except Exception as e:
            logger.error(f"Error getting encodings: {e}")
            return []

    @staticmethod
    def capture_face():
        cap = None
        try:
            cap = cv2.VideoCapture(0)
            if not cap.isOpened():
                logger.error("Failed to open camera")
                return None
            
            best_frame = None
            max_faces = 0
            
            for _ in range(30):  # Capture 30 frames
                ret, frame = cap.read()
                if not ret:
                    break
                    
                rgb_frame = frame[:, :, ::-1]  # BGR to RGB
                face_locations = face_recognition.face_locations(rgb_frame, model=Config.MODEL)
                
                if len(face_locations) > max_faces:
                    best_frame = frame
                    max_faces = len(face_locations)
            
            if best_frame is not None:
                temp_path = "static/temp_capture.jpg"
                cv2.imwrite(temp_path, best_frame)
                return temp_path
            return None
        except Exception as e:
            logger.error(f"Error capturing face: {e}")
            return None
        finally:
            if cap is not None:
                cap.release()

    @staticmethod
    def is_valid_registration(image_path):
        try:
            encodings = FaceEngine.get_encodings(image_path)
            return len(encodings) == 1  # Only allow single-face registration
        except Exception as e:
            logger.error(f"Error validating registration: {e}")
            return False

    @staticmethod
    def recognize(unknown_path, known_encodings):
        try:
            if not os.path.exists(unknown_path):
                logger.error(f"Unknown image file not found: {unknown_path}")
                return None
            
            unknown_encodings = FaceEngine.get_encodings(unknown_path)
            if not unknown_encodings:
                return None
                
            matches = face_recognition.compare_faces(
                known_encodings, 
                unknown_encodings[0], 
                tolerance=Config.TOLERANCE
            )
            
            # Return index of first match or None
            if True in matches:
                return matches.index(True)
            return None
        except Exception as e:
            logger.error(f"Error in face recognition: {e}")
            return None